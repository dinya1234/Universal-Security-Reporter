#!/usr/bin/env python3

import os
import json
import yaml
import argparse
import smtplib
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime
from dataclasses import dataclass, asdict
import re
import xml.etree.ElementTree as ET
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication

@dataclass
class SecurityIssue:
    tool: str
    severity: str
    title: str
    description: str
    file_path: str
    line_number: int = 0
    rule_id: str = ""
    category: str = ""
    confidence: str = "medium"

class EmailNotifier:
    """Менеджер SMTP уведомлений для Яндекс"""
    
    def __init__(self, config: Dict):
        self.config = config
    
    def send_report(self, report_data: Dict, html_report_path: str = None) -> bool:
        try:
            email_config = self.config['email']
            
            print(f" Отправка email через {email_config['smtp_server']}...")
            
     
            msg = MIMEMultipart()
            msg['From'] = email_config['from']
            msg['To'] = ', '.join(email_config['to'])
            msg['Subject'] = self._get_subject(report_data['summary'])
            
     
            text_content = self._format_text_report(report_data)
            msg.attach(MIMEText(text_content, 'plain', 'utf-8'))
            
      
            html_content = self._format_html_report(report_data)
            msg.attach(MIMEText(html_content, 'html', 'utf-8'))
            
       
            if html_report_path and Path(html_report_path).exists():
                with open(html_report_path, 'rb') as f:
                    attachment = MIMEApplication(f.read(), _subtype='html')
                    attachment.add_header(
                        'Content-Disposition', 
                        'attachment', 
                        filename=Path(html_report_path).name
                    )
                    msg.attach(attachment)
            
            
            with smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port']) as server:
                server.starttls()  
                server.login(email_config['username'], email_config['password'])
                server.send_message(msg)
            
            print(" Email успешно отправлен на volohovadaian@yandex.com")
            return True
            
        except Exception as e:
            print(f" Ошибка отправки email: {e}")
            return False
    
    def _get_subject(self, summary: Dict) -> str:
        """Формирует тему письма"""
        prefix = self.config['email'].get('subject_prefix', '[Security Scan]')
        critical = summary['by_severity'].get('critical', 0)
        high = summary['by_severity'].get('high', 0)
        total = summary['total_issues']
        
        if critical > 0:
            return f"{prefix}  КРИТИЧЕСКИЕ ОШИБКИ: {critical} критических, всего {total} проблем"
        elif high > 0:
            return f"{prefix}  ВНИМАНИЕ: {high} высоких рисков, всего {total} проблем"
        else:
            return f"{prefix}  УСПЕХ: Все тесты пройдены, проблем не найдено"
    
    def _format_text_report(self, report_data: Dict) -> str:
        """Форматирует текстовую версию отчета"""
        summary = report_data['summary']
        
        text = f"""
ОТЧЕТ О БЕЗОПАСНОСТИ
=====================

Дата сканирования: {summary['scan_time']}
Обработано инструментов: {len(summary['tools_processed'])}
Инструменты: {', '.join(summary['tools_processed'])}

СТАТИСТИКА ПРОБЛЕМ:
-------------------
Всего проблем: {summary['total_issues']}
• Критических: {summary['by_severity'].get('critical', 0)}
• Высоких: {summary['by_severity'].get('high', 0)}
• Средних: {summary['by_severity'].get('medium', 0)}
• Низких: {summary['by_severity'].get('low', 0)}

СТАТУС: {'ПРОВАЛ ' if summary['by_severity'].get('critical', 0) > 0 else 'УСПЕХ '}

ВАЖНЫЕ ПРОБЛЕМЫ:
----------------
"""
      
        issues_sorted = sorted(
            report_data['issues'], 
            key=lambda x: ['critical', 'high', 'medium', 'low', 'info'].index(x['severity'])
        )[:3]
        
        for i, issue in enumerate(issues_sorted, 1):
            severity_ru = {
                'critical': 'КРИТИЧЕСКАЯ',
                'high': 'ВЫСОКАЯ', 
                'medium': 'СРЕДНЯЯ',
                'low': 'НИЗКАЯ',
                'info': 'ИНФО'
            }.get(issue['severity'], 'НЕИЗВЕСТНАЯ')
            
            text += f"{i}. [{severity_ru}] {issue['tool']}: {issue['title']}\n"
            text += f"   Файл: {issue['file_path']}:{issue['line_number']}\n\n"
        
        text += f"\nСгенерировано Universal Security Reporter"
        return text
    
    def _format_html_report(self, report_data: Dict) -> str:
        """Форматирует HTML версию для email"""
        summary = report_data['summary']
        
        status_text = 'ПРОВАЛ ' if summary['by_severity'].get('critical', 0) > 0 else 'УСПЕХ '
        status_color = '#dc3545' if summary['by_severity'].get('critical', 0) > 0 else '#28a745'
        
        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; color: #333; }}
        .header {{ background: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .summary {{ background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0; }}
        .stats {{ display: flex; gap: 10px; margin: 15px 0; flex-wrap: wrap; }}
        .stat-card {{ background: white; padding: 15px; border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); min-width: 120px; text-align: center; }}
        .critical {{ color: #dc3545; font-weight: bold; }}
        .high {{ color: #fd7e14; }}
        .medium {{ color: #ffc107; }}
        .low {{ color: #17a2b8; }}
        .status {{ font-size: 18px; font-weight: bold; padding: 10px; border-radius: 5px; text-align: center; }}
    </style>
</head>
<body>
    <div class="header">
        <h1> Отчет о безопасности</h1>
        <p>Дата сканирования: {summary['scan_time']}</p>
    </div>
    
    <div class="summary">
        <h2> Общая статистика</h2>
        <p><strong>Инструменты:</strong> {', '.join(summary['tools_processed'])}</p>
        
        <div class="stats">
            <div class="stat-card">
                <div style="font-size: 24px; font-weight: bold;">{summary['total_issues']}</div>
                <div>Всего проблем</div>
            </div>
            <div class="stat-card">
                <div style="font-size: 24px; font-weight: bold;" class="critical">{summary['by_severity'].get('critical', 0)}</div>
                <div>Критических</div>
            </div>
            <div class="stat-card">
                <div style="font-size: 24px; font-weight: bold;" class="high">{summary['by_severity'].get('high', 0)}</div>
                <div>Высоких</div>
            </div>
            <div class="stat-card">
                <div style="font-size: 24px; font-weight: bold;" class="medium">{summary['by_severity'].get('medium', 0)}</div>
                <div>Средних</div>
            </div>
        </div>
        
        <div class="status" style="background: {status_color}; color: white;">
            {status_text}
        </div>
    </div>
    
    <p><em>Полный отчет прикреплен в виде HTML файла.</em></p>
    <hr>
    <p style="color: #666; font-size: 12px;">Сгенерировано Universal Security Reporter</p>
</body>
</html>
"""

class UniversalSecurityReporter:
    """УНИВЕРСАЛЬНЫЙ репортер для сбора, парсинга и email уведомлений"""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.issues = []
        self.summary = {
            'total_issues': 0,
            'by_severity': {},
            'by_tool': {},
            'tools_processed': [],
            'scan_time': datetime.now().isoformat()
        }
        

        if self.config['notifications'].get('enabled', False) and \
           self.config['notifications'].get('email', {}).get('enabled', False):
            self.email_notifier = EmailNotifier(self.config['notifications'])
            print(" Email уведомления включены")
        else:
            self.email_notifier = None
    
    def _load_config(self, config_path: str) -> Dict:
        """Загрузка конфигурации"""
        default_config = {
            'output_dir': 'outputs',
            'report_title': 'Security Scan Report',
            'severity_mapping': {
                'CRITICAL': 'critical', 'HIGH': 'high', 'MEDIUM': 'medium', 
                'LOW': 'low', 'INFO': 'info', 'BLOCKER': 'critical',
                'MAJOR': 'high', 'MINOR': 'medium', 'ERROR': 'high',
                'WARNING': 'medium'
            },
            'notifications': {
                'enabled': False,
                'email': {
                    'enabled': False,
                    'smtp_server': 'smtp.yandex.ru',
                    'smtp_port': 587,
                    'username': '',
                    'password': '',
                    'from': '',
                    'to': [],
                    'subject_prefix': '[Security Scan]'
                }
            }
        }
        
        if Path(config_path).exists():
            with open(config_path, 'r') as f:
                user_config = yaml.safe_load(f)
                if user_config:
                    default_config.update(user_config)
        
        return default_config
    
    def collect_and_parse_reports(self, reports_dir: str) -> Dict[str, Any]:
        """Собирает и парсит все отчеты в директории"""
        print(f" Сбор и анализ отчетов из: {reports_dir}")
        
        reports_path = Path(reports_dir)
        if not reports_path.exists():
            raise FileNotFoundError(f"Директория {reports_dir} не найдена")
        
        file_count = 0
        for file_path in reports_path.rglob('*'):
            if file_path.is_file() and not file_path.name.startswith('.'):
                file_count += 1
                print(f"   📄 Обработка: {file_path.name}")
                self._parse_universal(file_path)
        
        print(f"Обработано файлов: {file_count}")
        print(f" Найдено проблем: {len(self.issues)}")
        
        return self._generate_consolidated_report()
    
    def _parse_universal(self, file_path: Path) -> None:
        """Универсальный парсер для всех форматов"""
        try:
            content = self._read_file(file_path)
            if not content:
                return
            
            tool_type = self._detect_tool_type(file_path, content)
            print(f"       Определен инструмент: {tool_type}")
            
            if tool_type == "sonarqube":
                issues = self._parse_sonarqube(content)
            elif tool_type == "zap":
                issues = self._parse_zap(content)
            elif tool_type == "bandit":
                issues = self._parse_bandit(content)
            elif tool_type == "flake8":
                issues = self._parse_flake8(content, str(file_path))
            elif tool_type == "jacoco":
                issues = self._parse_jacoco(content)
            elif tool_type == "generic_json":
                issues = self._parse_generic_json(content)
            else:
                issues = []
            
            for issue in issues:
                issue.tool = tool_type
                self.issues.append(issue)
                
        except Exception as e:
            print(f"      Ошибка парсинга {file_path.name}: {e}")
    
    def _detect_tool_type(self, file_path: Path, content: str) -> str:
        """Автоматическое определение типа инструмента"""
        file_name = file_path.name.lower()
        
        if any(pattern in file_name for pattern in ['sonar', 'sq_']):
            return "sonarqube"
        elif any(pattern in file_name for pattern in ['zap', 'owasp']):
            return "zap"
        elif any(pattern in file_name for pattern in ['bandit']):
            return "bandit"
        elif any(pattern in file_name for pattern in ['flake8', 'pep8']):
            return "flake8"
        elif any(pattern in file_name for pattern in ['jacoco', 'coverage']):
            return "jacoco"
        
      
        if file_name.endswith('.xml'):
            try:
                root = ET.fromstring(content)
                if root.tag == 'report' and 'jacoco' in str(root.attrib):
                    return "jacoco"
            except:
                pass
        
      
        try:
            data = json.loads(content)
            if 'issues' in data and 'components' in data:
                return "sonarqube"
            elif 'site' in data:
                return "zap"
            elif 'results' in data and 'metrics' in data:
                return "bandit"
            else:
                return "generic_json"
        except:
            pass
        
        return "unknown"
    
    def _parse_sonarqube(self, content: str) -> List[SecurityIssue]:
        """Парсинг SonarQube формата"""
        issues = []
        try:
            data = json.loads(content)
            
            for issue in data.get('issues', []):
                severity = self._normalize_severity(issue.get('severity', 'INFO'))
                issues.append(SecurityIssue(
                    tool="sonarqube",
                    severity=severity,
                    title=f"{issue.get('type', 'ISSUE')}: {issue.get('message', '')}",
                    description=issue.get('message', ''),
                    file_path=issue.get('component', '').split(':')[-1],
                    line_number=issue.get('line', 0),
                    rule_id=issue.get('rule', ''),
                    category=issue.get('type', '')
                ))
                
        except Exception as e:
            print(f"      Ошибка парсинга SonarQube: {e}")
            
        return issues
    
    def _parse_zap(self, content: str) -> List[SecurityIssue]:
        """Парсинг OWASP ZAP формата"""
        issues = []
        try:
            data = json.loads(content)
            
            for site in data.get('site', []):
                for alert in site.get('alerts', []):
                    risk = alert.get('risk', 'Medium')
                    severity = 'high' if risk == 'High' else 'medium' if risk == 'Medium' else 'low'
                    
                    issues.append(SecurityIssue(
                        tool="zap",
                        severity=severity,
                        title=f"[{risk}] {alert.get('alert', '')}",
                        description=alert.get('desc', ''),
                        file_path=site.get('@name', ''),
                        rule_id=alert.get('pluginid', ''),
                        category=alert.get('alert', '')
                    ))
                    
        except Exception as e:
            print(f"      Ошибка парсинга ZAP: {e}")
            
        return issues
    
    def _parse_bandit(self, content: str) -> List[SecurityIssue]:
        """Парсинг Bandit формата"""
        issues = []
        try:
            data = json.loads(content)
            
            for result in data.get('results', []):
                severity = self._normalize_severity(result.get('issue_severity', 'MEDIUM'))
                
                issues.append(SecurityIssue(
                    tool="bandit",
                    severity=severity,
                    title=f"{result.get('issue_confidence', '').upper()}: {result.get('issue_text', '')}",
                    description=result.get('issue_text', ''),
                    file_path=result.get('filename', ''),
                    line_number=result.get('line_number', 0),
                    rule_id=result.get('test_id', ''),
                    category=result.get('test_name', '')
                ))
                
        except Exception as e:
            print(f"      Ошибка парсинга Bandit: {e}")
            
        return issues
    
    def _parse_flake8(self, content: str, file_path: str) -> List[SecurityIssue]:
        """Парсинг Flake8 формата"""
        issues = []
        try:
            for line in content.strip().split('\n'):
                if not line.strip():
                    continue
                    
                match = re.match(r'(.+?):(\d+):(\d+):\s*(\w+)\s*(.+)', line)
                if match:
                    file_path, line_num, col, code, message = match.groups()
                    severity = 'medium' if code.startswith(('E', 'F')) else 'low'
                    
                    issues.append(SecurityIssue(
                        tool="flake8",
                        severity=severity,
                        title=f"{code}: {message}",
                        description=message,
                        file_path=file_path,
                        line_number=int(line_num),
                        rule_id=code,
                        category='code_style'
                    ))
                    
        except Exception as e:
            print(f"      Ошибка парсинга Flake8: {e}")
            
        return issues
    
    def _parse_jacoco(self, content: str) -> List[SecurityIssue]:
        """Парсинг JaCoCo XML формата (test coverage)"""
        issues = []
        try:
            root = ET.fromstring(content)
            

            for counter in root.findall('.//counter'):
                counter_type = counter.get('type', '')
                covered = int(counter.get('covered', 0))
                missed = int(counter.get('missed', 0))
                total = covered + missed
                
                if total > 0:
                    coverage_percent = (covered / total) * 100
                    
                    if coverage_percent < 80:
                        issues.append(SecurityIssue(
                            tool="jacoco",
                            severity="medium",
                            title=f"Low {counter_type} coverage: {coverage_percent:.1f}%",
                            description=f"{counter_type} coverage is {coverage_percent:.1f}% (minimum 80% required)",
                            file_path="project",
                            category="test_coverage",
                            rule_id=f"coverage_{counter_type}"
                        ))
                        
        except Exception as e:
            print(f"      Ошибка парсинга JaCoCo: {e}")
            
        return issues
    
    def _parse_generic_json(self, content: str) -> List[SecurityIssue]:
        """Парсинг generic JSON формата"""
        issues = []
        try:
            data = json.loads(content)
            issues.extend(self._extract_from_generic_dict(data, "generic_json"))
        except Exception as e:
            print(f"      Ошибка парсинга generic JSON: {e}")
            
        return issues
    
    def _extract_from_generic_dict(self, data: Dict, tool_name: str) -> List[SecurityIssue]:
        issues = []
        
        if isinstance(data, dict):
            if any(key in data for key in ['severity', 'level', 'priority', 'risk']):
                severity = self._normalize_severity(
                    data.get('severity') or data.get('level') or data.get('priority') or data.get('risk', 'medium')
                )
                
                issues.append(SecurityIssue(
                    tool=tool_name,
                    severity=severity,
                    title=data.get('title') or data.get('message') or data.get('description', 'Unknown issue'),
                    description=data.get('description') or data.get('message') or '',
                    file_path=data.get('file') or data.get('file_path') or data.get('location', ''),
                    line_number=data.get('line') or data.get('line_number') or 0,
                    rule_id=data.get('rule_id') or data.get('id') or '',
                    category=data.get('category') or data.get('type') or ''
                ))
            
            for value in data.values():
                if isinstance(value, (dict, list)):
                    issues.extend(self._extract_from_generic_dict(value, tool_name))
                    
        elif isinstance(data, list):
            for item in data:
                issues.extend(self._extract_from_generic_dict(item, tool_name))
                
        return issues
    
    def _normalize_severity(self, severity: str) -> str:
        """Приводит severity к универсальному формату"""
        severity_str = str(severity).upper().strip()
        return self.config['severity_mapping'].get(severity_str, 'medium')
    
    def _read_file(self, file_path: Path) -> str:
        """Чтение файла с автоопределением кодировки"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        except UnicodeDecodeError:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception as e:
            print(f"      Ошибка чтения файла {file_path}: {e}")
            return ""
    
    def _generate_consolidated_report(self) -> Dict[str, Any]:
        """Генерация консолидированного отчета"""
        severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        tool_counts = {}
        
        for issue in self.issues:
            severity_counts[issue.severity] = severity_counts.get(issue.severity, 0) + 1
            tool_counts[issue.tool] = tool_counts.get(issue.tool, 0) + 1
        
        self.summary.update({
            'total_issues': len(self.issues),
            'by_severity': severity_counts,
            'by_tool': tool_counts,
            'tools_processed': list(tool_counts.keys())
        })
        
        return {
            'summary': self.summary,
            'issues': [asdict(issue) for issue in self.issues]
        }
    
    def generate_html_document(self, output_path: str = None) -> str:
        """Генерация удобочитаемого HTML документа"""
        if not output_path:
            output_path = Path(self.config['output_dir']) / 'security_report.html'
        
        report_data = self._generate_consolidated_report()
        html_content = self._create_html_template(report_data)
        
        Path(self.config['output_dir']).mkdir(exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f" HTML документ создан: {output_path}")
        return str(output_path)
    
    def _create_html_template(self, report_data: Dict) -> str:
        """Создание HTML шаблона отчета"""
        summary = report_data['summary']
        issues = report_data['issues']
    
        severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
        issues.sort(key=lambda x: severity_order.get(x['severity'], 5))
    
        issues_rows = ""
        for issue in issues:
            severity_class = f"severity-{issue['severity']}"
        

            severity_translation = {
                'critical': 'КРИТИЧЕСКИЙ',
                'high': 'ВЫСОКИЙ', 
                'medium': 'СРЕДНИЙ',
                'low': 'НИЗКИЙ',
                'info': 'ИНФО'
            }
        
            severity_text = severity_translation.get(issue['severity'], issue['severity'].upper())
        
            issues_rows += f"""
            <tr class="{severity_class}">
                <td>{issue['tool']}</td>
                <td><span class="severity-badge">{severity_text}</span></td>
                <td>{issue['title']}</td>
                <td>{issue['file_path']}:{issue['line_number']}</td>
                <td>{issue['category']}</td>
            </tr>
            """
    

        status_text = " НЕ УСПЕШНО" if summary['by_severity'].get('critical', 0) > 0 else " УСПЕШНО"
    
        return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>{self.config['report_title']}</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            .summary {{ background: #f5f5f5; padding: 20px; border-radius: 5px; margin-bottom: 20px; }}
            .severity-critical {{ background: #ffe6e6; }}
            .severity-high {{ background: #fff0e6; }}
            .severity-medium {{ background: #fff9e6; }}
            .severity-low {{ background: #e6f7ff; }}
            .severity-badge {{ 
                padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; color: white;
            }}
            .severity-critical .severity-badge {{ background: #dc3545; }}
            .severity-high .severity-badge {{ background: #fd7e14; }}
            .severity-medium .severity-badge {{ background: #ffc107; color: black; }}
            .severity-low .severity-badge {{ background: #17a2b8; }}
            table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
            th {{ background-color: #343a40; color: white; }}
            .stats {{ display: flex; gap: 15px; margin: 15px 0; }}
            .stat-card {{ background: white; padding: 15px; border-radius: 5px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); min-width: 120px; text-align: center; }}
            .stat-value {{ font-size: 24px; font-weight: bold; }}
            .critical {{ color: #dc3545; }}
            .high {{ color: #fd7e14; }}
            .medium {{ color: #ffc107; }}
            .low {{ color: #17a2b8; }}
        </style>
    </head>
    <body>
        <h1> {self.config['report_title']}</h1>
        
        <div class="summary">
            <h2>📊 Общая сводка</h2>
            <p><strong>Время сканирования:</strong> {summary['scan_time']}</p>
            <p><strong>Обработанные инструменты:</strong> {', '.join(summary['tools_processed'])}</p>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-value">{summary['total_issues']}</div>
                    <div>Всего проблем</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value critical">{summary['by_severity'].get('critical', 0)}</div>
                    <div>Критические</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value high">{summary['by_severity'].get('high', 0)}</div>
                    <div>Высокие</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value medium">{summary['by_severity'].get('medium', 0)}</div>
                    <div>Средние</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value low">{summary['by_severity'].get('low', 0)}</div>
                    <div>Низкие</div>
                </div>
            </div>
            
            <p><strong>Статус:</strong> {status_text}</p>
        </div>

        <h2> Детализация проблем</h2>
        <table>
            <thead>
                <tr>
                    <th>Инструмент</th>
                    <th>Уровень риска</th>
                    <th>Описание</th>
                    <th>Местоположение</th>
                    <th>Категория</th>
                </tr>
            </thead>
            <tbody>
                {issues_rows if issues_rows else '<tr><td colspan="5">Проблем не найдено</td></tr>'}
            </tbody>
        </table>
    </body>
    </html>
    """
    
    def send_email_notifications(self, report_data: Dict, html_report_path: str = None) -> bool:
        """Отправляет уведомления по email"""
        if not self.email_notifier:
            print("ℹ Email уведомления отключены")
            return False
        
        print("Отправка email уведомлений...")
        return self.email_notifier.send_report(report_data, html_report_path)

def main():
    parser = argparse.ArgumentParser(description=' Универсальный репортер безопасности')
    parser.add_argument('--reports-dir', '-r', required=True, help='Директория с отчетами')
    parser.add_argument('--config', '-c', default='config.yaml', help='Конфигурационный файл')
    parser.add_argument('--output', '-o', help='Выходной файл для HTML отчета')
    parser.add_argument('--send-email', '-e', action='store_true', help='Отправить уведомления по email')
    
    args = parser.parse_args()
    
    try:
        print(" Запуск Universal Security Reporter...")
        
        reporter = UniversalSecurityReporter(args.config)
        report_data = reporter.collect_and_parse_reports(args.reports_dir)
        html_report_path = reporter.generate_html_document(args.output)
        
        if args.send_email:
            reporter.send_email_notifications(report_data, html_report_path)
        
        summary = report_data['summary']
        print(f"\n ИТОГИ:")
        print(f"     Инструментов: {len(summary['tools_processed'])}")
        print(f"    Всего проблем: {summary['total_issues']}")
        print(f"   🔴 Critical: {summary['by_severity'].get('critical', 0)}")
        print(f"   🟠 High: {summary['by_severity'].get('high', 0)}")
        print(f"   🟡 Medium: {summary['by_severity'].get('medium', 0)}")
        print(f"   🔵 Low: {summary['by_severity'].get('low', 0)}")
        print(f"    Отчет: {html_report_path}")
        
    except Exception as e:
        print(f" Ошибка: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main())